import fatec.poo.model.ContaCorrente;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        ContaCorrente[] objConta = new ContaCorrente[2];

        int numero;
        double saldo;

        for (int i = 0; i < objConta.length; i++) {
            System.out.println("Digite o número da conta:");
            numero = entrada.nextInt();
            System.out.println("Digite o saldo atual da conta:");
            saldo = entrada.nextDouble();
            objConta[i] = new ContaCorrente(numero, saldo);
        }

        int opcao;

            do {
                System.out.println("\n1 - Depositar");
                System.out.println("2 - Sacar");
                System.out.println("3 - Consultar Saldo");
                System.out.println("4 - Listar contas");
                System.out.println("5 - Sair");
                System.out.println("Digite a opção: ");
                opcao = entrada.nextInt();

                    switch (opcao) {
                        case 1: {
                            System.out.println("Digite o numero da conta a ser depositado");
                            numero = entrada.nextInt();
                            for (int i = 0; i < objConta.length; i++) {
                                if (objConta[i].getNumero() == numero)  {
                                System.out.println("Digite o valor a ser depositado:");
                                double ValDeposito = entrada.nextDouble();
                                System.out.println("Depositado com sucesso!");
                                objConta[i].depositar(ValDeposito);
                                }
                            }
                            break;
                        }
                        case 2: {
                            System.out.println("Digite o numero da conta a ser sacado");
                            numero = entrada.nextInt();
                            for (int i = 0; i < objConta.length; i++) {
                                if (objConta[i].getNumero() == numero) {
                                    System.out.println("Digite o valor a ser sacado");
                                    double ValSaque = entrada.nextDouble();
                                    if (ValSaque >= objConta[i].getSaldo()) {
                                        System.out.println("Saldo insuficiente!");
                                        break;
                                    }
                                    else {
                                        objConta[i].sacar(ValSaque);
                                        System.out.println("Sacado com sucesso!!");
                                        break;
                                    }
                                }
                                if(i == objConta.length - 1){
                                    System.out.println("Numero inválido");
                                    break;
                                }
                            }
                            break;
                        }
                        case 3: {
                            System.out.println("Digite o numero da conta para consultar o saldo");
                            numero = entrada.nextInt();
                            for (int i = 0; i < objConta.length; i++) {
                                if (objConta[i].getNumero() == numero) {
                                    System.out.println("Saldo atual: " + objConta[i].getSaldo());
                                }
                            }
                            break;
                        }
                        case 4: {
                            for (int i = 0; i < objConta.length; i++) {
                                System.out.println("Numero da conta: " + objConta[i].getNumero());
                                System.out.println("Saldo atual: " + objConta[i].getSaldo());
                            }
                            break;
                        }
                    }
                } while (opcao < 5);
            }

        }

