import fatec.poo.model.Cliente;
import fatec.poo.model.Instrutor;

public class Main {
    public static void main(String[] args) {

        Cliente objCliente = new Cliente("476761778-20", "Ravena", "(15) 99633-9733");
        Instrutor objInstrutor = new Instrutor(1233, "Dimas", "(15) 99001-9865");


        objCliente.setAltura(1.60);
        objCliente.setPeso(60.0);

        System.out.println("Cpf do cliente: " + objCliente.getCpf());
        System.out.println("Nome do cliente: " + objCliente.getNome());
        System.out.println("Telefone do cliente: " + objCliente.getTelefone());
        System.out.println("Peso do cliente: " + objCliente.getPeso());
        System.out.println("Altura do cliente: " + objCliente.getAltura());
        System.out.println("IMC do cliente: " + objCliente.calcIMC());

        objInstrutor.setAreaAtuacao("Matematica");

        System.out.println("/nIdentificação do instrutor: " + objInstrutor.getIdentificacao());
        System.out.println("Nome do instrutor: " + objInstrutor.getNome());
        System.out.println("Telefone do instrutor: " + objInstrutor.getTelefone());

    }
}