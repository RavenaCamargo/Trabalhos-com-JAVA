package fatec.poo.model;

public class funcionarioComissionado extends funcionario {
    private double salBase;
    private double taxaComissao;
    private double valVendas;
    private double totalVendas;

    public funcionarioComissionado (int registro, String nome, String dtAdmissao, double taxaComissao) {
        super(registro, nome, dtAdmissao);
        this.taxaComissao = taxaComissao;
    }

    public double getSalBase() {
        return salBase;
    }

    public void setSalBase(double salBase) {
        this.salBase = salBase;
    }

    public double getTotalVendas() {
        return (totalVendas * valVendas);
    }

    public double getTaxaComissao() {
        return taxaComissao;
    }

    public void setAddVendas (double valVendas) {
        this.valVendas = valVendas;
    }

    public double calcSalBruto() {
        return (getSalBase() + getTaxaComissao() * getTotalVendas());
    }

    public double calcGratificacao () {
        if (getTotalVendas() <= 5000)
            return 0;
        else if (getTotalVendas() > 5000 && getTotalVendas() < 10000)
            return (calcSalBruto() * 0.3);
        else if (getTotalVendas() > 10000)
            return (calcSalBruto() * 0.5);
        return 0;
    }

    public double calcSalLiquido() {
        return (calcSalBruto() - calcDesconto() + calcGratificacao());
    }
}
