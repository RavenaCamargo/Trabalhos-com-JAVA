package fatec.poo.model;

public class funcionarioMensalista extends funcionario{
    private double valSalMin;
    private double numSalMin;

    public funcionarioMensalista (int registro, String nome, String dtAdmissao, double valSalMin) {
        super(registro, nome, dtAdmissao);
        this.valSalMin = valSalMin;
    }

    public void setNumSalMin(double numSalMin) {
        this.numSalMin = numSalMin;
    }

    public double calcSalBruto () {
        return (valSalMin * numSalMin);
    }

    public double calcSalLiquido () {
        return (calcSalBruto() - calcDesconto());
    }
}
