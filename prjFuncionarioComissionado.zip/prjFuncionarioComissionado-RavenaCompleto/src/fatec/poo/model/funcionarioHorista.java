package fatec.poo.model;

public class funcionarioHorista extends funcionario{
    private double valHorTrab;
    private int qtdeHorTrab;

    public funcionarioHorista (int registro, String nome, String dtAdmissao, double valHorTrab){
        super(registro, nome, dtAdmissao);
        this.valHorTrab = valHorTrab;
    }

    public void setQtdeHorTrab (int qtdeHorTrab) {
        this.qtdeHorTrab = qtdeHorTrab;
    }

    public double calcSalBruto () {
        return (valHorTrab * qtdeHorTrab);
    }

    public double calcGratificacao () {
        return (0.075 * calcSalBruto());
    }

    public double calcSalLiquido() {
        return (calcSalBruto() + calcGratificacao() - calcDesconto());
    }
}
