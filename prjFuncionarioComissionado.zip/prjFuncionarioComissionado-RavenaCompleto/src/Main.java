import java.text.DecimalFormat;
import fatec.poo.model.funcionarioComissionado;
import fatec.poo.model.funcionarioHorista;
import fatec.poo.model.funcionarioMensalista;
public class Main {
    public static void main(String[] args) {
        DecimalFormat df = new DecimalFormat("#,##0.00");

        funcionarioHorista funcHor = new funcionarioHorista(1010,
                "Pedro Silveira",
                "14/05/1978",
                15.80);

        funcionarioMensalista funcMen = new funcionarioMensalista(2020,
                "Ana Beatriz",
                "22/10/1997",
                600.0);

        funcionarioComissionado funcCom = new funcionarioComissionado(3030,
                "Ravena Camargo",
                "29/06/1998",
                0.1);

        //Funcionario horista:
        funcHor.setCargo("Programador");
        funcHor.setQtdeHorTrab(90);
        System.out.println("Registro        => " + funcHor.getRegistro());
        System.out.println("Nome            => " + funcHor.getNome());
        System.out.println("Data Admissão   => " + funcHor.getDtAdmissao());
        System.out.println("Cargo           => " + funcHor.getCargo());
        System.out.println("Salário Bruto   => " +
                df.format(funcHor.calcSalBruto()));
        System.out.println("Desconto        => " +
                df.format(funcHor.calcDesconto()));
        System.out.println("Gratificação    => " +
                df.format(funcHor.calcGratificacao()));
        System.out.println("Salário Liquido => " +
                df. format(funcHor.calcSalLiquido()));

        //Funcionario mensalista:
        funcMen.setCargo("Aux. Administrativo");
        funcMen.setNumSalMin(2.5);
        System.out.println("\n\nRegistro        => " + funcMen.getRegistro());
        System.out.println("Nome            => " + funcMen.getNome());
        System.out.println("Data Admissão   => " + funcMen.getDtAdmissao());
        System.out.println("Cargo           => " + funcMen.getCargo());
        System.out.println("Salario Bruto   => " +
                df.format(funcMen.calcSalBruto()));
        System.out.println("Desconto        => " +
                df.format(funcMen.calcDesconto()));
        System.out.println("Salario Liquido => " +
                df.format(funcMen.calcSalLiquido()));

        //Funcionario Comissionado:
        funcCom.setCargo("Vendedor");
        funcCom.setSalBase(800.00);
        funcCom.setAddVendas(100.00);
        System.out.println("\n\nRegistro        => " + funcCom.getRegistro());
        System.out.println("Nome            => " + funcCom.getNome());
        System.out.println("Data Admissão   => " + funcCom.getDtAdmissao());
        System.out.println("Cargo           => " + funcCom.getCargo());
        System.out.println("Total de vendas =>" + funcCom.getTotalVendas());
        System.out.println("Salario Bruto   => " + df.format(funcCom.calcSalBruto()));
        System.out.println("Desconto        => " + df.format(funcCom.calcDesconto()));
        System.out.println("Gratificacao    =>" + df.format(funcCom.calcGratificacao()));
        System.out.println("Salario Liquido => " + df.format(funcCom.calcSalLiquido()));


    }
}