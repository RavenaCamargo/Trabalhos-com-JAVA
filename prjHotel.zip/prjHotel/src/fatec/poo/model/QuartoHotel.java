package fatec.poo.model;

public class QuartoHotel {
    private int numQuarto;
    private double valDiaria;
    private int numRG;
    private boolean situacao;
    private double totalFaturado;

    public QuartoHotel (int numQuarto, double valDiaria) {
        this.numQuarto = numQuarto;
        this.valDiaria = valDiaria;
        situacao = false;
    }

    public void reservar (int numRG) {
        situacao = true;
    }

    public double liberar (int numDiasPermanencia) {
        totalFaturado = numDiasPermanencia * valDiaria;
        numRG = 0;
        situacao = false;
        return totalFaturado;
    }

    public boolean getSituacao() {
        return situacao;
    }

    public void setSituacao(boolean situacao) {
        this.situacao = situacao;
    }

    public double getTotalFaturado() {
        return totalFaturado;
    }
}
