import fatec.poo.model.QuartoHotel;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        QuartoHotel objQuartoHotel[] = new QuartoHotel[5];

        int opcao, numQuarto;
        double valDiaria;

        for (int i = 0; i < objQuartoHotel.length; i++) {
            System.out.println("Digite o número do quarto:");
            numQuarto = entrada.nextInt();
            System.out.println("Digite o val da diária:");
            valDiaria = entrada.nextInt();
|           objQuartoHotel[i] = new QuartoHotel(numQuarto, valDiaria);
        }

        do {
            System.out.println("\n1 - Consultar quarto");
            System.out.println("2 - Reservar quarto");
            System.out.println("3 - Liberar quarto");
            System.out.println("4 - Consultar faturamento quarto");
            System.out.println("5 - Consultar faturamento hotel");
            System.out.println("6 - Sair");
            System.out.print("\n\tDigite a opcao: ");
            opcao = entrada.nextInt();

            switch (opcao) {
                case 1:
                    for( int i=0; i < 5; i++) {
                        System.out.println("Digite o numero do quarto: ");
                        numQuarto = entrada.nextInt();

                    }
                case 2:

                case 3:

                case 4:

                case 5:

            }
        }while (opcao < 6);

    }
}