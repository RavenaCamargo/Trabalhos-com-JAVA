package fatec.poo.model;

public class Main {
    public static void main(String[] args) {

        Circulo[] circulos = new Circulo[10];

        circulos[0] = new Circulo(2.0);
        circulos[1] = new Circulo(3.0);
        circulos[2] = new Circulo(4.0);
        circulos[3] = new Circulo(5.0);
        circulos[4] = new Circulo(6.0);
        circulos[5] = new Circulo(7.0);
        circulos[6] = new Circulo(8.0);
        circulos[7] = new Circulo(9.0);
        circulos[8] = new Circulo(10.0);
        circulos[9] = new Circulo(11.0);

        /*
        *FAzer um scanner*
        Scanner entrada = new sacanner (System.in);

        for (int i = 0; i < circulos.length; i++) {
            System.out.println("Digite o valor do raio: ");
            double raio = entrada.nextDouble();
        }
         */

        for (int i = 0; i < circulos.length; i++) {
            System.out.println("Circulo " + (i+1) + ":");
            System.out.println("Raio: " + circulos[i].getRaio());
            System.out.println("Diametro: " + circulos[i].getDiametro());
            System.out.println("Perimetro: " + circulos[i].getPerimetro());
            System.out.println("Area: " + circulos[i].getArea());
            System.out.println();
        }
    }
}