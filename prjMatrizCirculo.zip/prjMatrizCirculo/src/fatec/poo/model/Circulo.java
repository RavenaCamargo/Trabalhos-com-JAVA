package fatec.poo.model;

public class Circulo {
    private double raio;
    private double PI = 3.14159;

    public Circulo(double raio) {
        this.raio = raio;
    }

    public double getRaio() { return raio; }

    public double getDiametro() {
        return 2 * raio;
    }

    public double getPerimetro() {
        return 2 * PI * raio;
    }

    public double getArea() {
        return PI * raio * raio;
    }
}

